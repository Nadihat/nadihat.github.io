<?php
include 'log.php';

// Symbolic connection to Servitor
//logAction("Connected to the Servitor for intention setting");

echo "The Servitor is now connected.";
?>
